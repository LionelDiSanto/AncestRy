#### Import the pipe operator from magrittr ####
#' Pipe operator
#'
#' @name %>%
#' @rdname pipe
#' @keywords internal
#' @export
#' @importFrom magrittr %>%
#' @usage lhs \%>\% rhs
NULL

#' @importFrom progress progress_bar
NULL
#' @importFrom stats rnorm runif rbinom rpois
NULL
#' @importFrom utils write.table combn
NULL
#' @importFrom progress progress_bar
NULL


